CREATE TRIGGER expTime
BEFORE INSERT ON Abonamente
FOR EACH ROW
  SET NEW.Valabilitate = date_add(sysdate(),INTERVAL 6 MONTH);
